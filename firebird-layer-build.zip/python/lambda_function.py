import json
import fdb

def lambda_handler(event, context):
    con = fdb.connect(dsn='SKF-FIREBIRD01:C:\\SKF\\DB_SAM\\BRAEO07_SAM.gdb', user='sysdba', password='masterkey')
